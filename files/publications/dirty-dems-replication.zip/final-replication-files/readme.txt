
This is a replication archive for the paper: 

"Anti-Corruption Efforts and Electoral Manipulation in Democracies" by Marko Klasnja and Grigore Pop-Eleches, forthcoming in the Journal of Politics. 

The files contained in this replication archive are: 

1. analysis_db_sv.dta --- main dataset for analysis, at the polling station level
2. paper.do --- replication code for results in the paper
3. appendix.do --- replication code for most of the results in the appendix
4. analysis_db_locality.dta --- auxiliary dataset for analysis, at the locality (municipality) level
5. survey.dta --- survey data for analysis (used for Figures 3 and A11)
6. figureA6_data --- auxiliary dataset at the locality level (used for Figure A6)
7. tableA3_data --- auxiliary dataset at the locality level (used in the DiD analysis in Table A3)
8. birch-data.dta, kelley-qed.dta, pei-v6.dta, qog_std_cs_jan18.dta, V-Dem-CY-v8.dta --- datasets for Figures 1 and A1 (see paper and appendix for citations; pei-v6, qog_std_cs_jan18.dta, and V-Dem-CY-v8.dta contain only the relevant subsets of the original data)
9. Figures-1-and-A1.do --- replication code for Figures 1 and A1

Final analyses were run on Stata/SE 16.1 for Windows, Revision 28 Apr 2020. 

The replication requires the following user-written packages for Stata: coefplot, frmttable, estout, robjb, medcouple, moremata, rdrobust, and psmatch2. See the do-files for more information. 

For any questions or concerns, please email marko.klasnja@georgetown.edu. 
