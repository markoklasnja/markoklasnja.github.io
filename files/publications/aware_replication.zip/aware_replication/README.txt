This archive contains files needed to replicate the results in "Uninformed Voters and Corrupt Incumbents," American Politics Research, 2017, 45(2), 256�279.

The results were last replicated on October 25, 2017, on a Windows 7 Enterprise machine using Stata 14. 

In addition to Stata 14's built-in functions, the replication do-files use three user-written packages that would need to be installed for the replication do-files to execute: 

-mim-
-frmttable-
-outreg2-

Use the -findit- or -net search- functions in Stata to find and download these ado packages. 

The house.dta, house9092.dta, and senate.dta datasets are multiply imputed, with 15 imputed datasets stacked together. The imputations were performed using the user-written package -ice-. The do-files used for imputations and data preparation (as well as do-files used to build the year-by-year political awareness scales) are not included in this replication archive. However, they are available upon request. 

The replication archive also contains slightly reformatted data from: 

- Caughey, Devin, and Jasjeet S. Sekhon. "Elections and the regression discontinuity design: Lessons from close US house races, 1942�2008." Political Analysis 19, no. 4 (2011): 385-408. (called caughey-sekhon.dta in the archive)

- Ansolabehere, Stephen, James M. Snyder Jr, and Charles Stewart III. "Candidate positioning in US House elections." American Journal of Political Science (2001): 136-159. (called ansolabehere-et-al.dta in the arhive)

These data are needed for replication of several tables in the Supplementary Appendix. 

For any questions, comments or requests, please contact me at marko.klasnja@georgetown.edu.

Marko Kla�nja
Assistant Professor
Edmund A. Walsh School of Foreign Service and Government Department
Georgetown University


