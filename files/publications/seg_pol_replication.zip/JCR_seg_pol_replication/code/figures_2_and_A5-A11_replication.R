# This R script creates graphs in the paper and the online appendix based on the simulated data
# described in the text. The figures replicated with this code are: Figure 2 and Figures A5-A11.
# For more details on the code, see the comments interspersed below

# install packages
install.packages("mgcv")
install.packages("foreign")
install.packages("fields")
install.packages("MASS")
install.packages("car")
install.packages("lmtest")

# load libraries
library(mgcv)
library(foreign)
library(fields)
library(MASS)
library(car)
library(lmtest)
library(stats)

# set the working directory (here, adjust to match the path on your local drive)
setwd("C:/Users/Marko/Dropbox/ABM Dynamics of ethnic war project/data/JCR_seg_pol_replication")

# read in the simulated data
data = read.dta("data/simulated_data.dta", convert.factors=FALSE, convert.underscore=TRUE)

# import data with predictions from a negative binomial model (see "table_1_replication.do")
sim.preds.data = read.dta("data/simulated_nbreg_preds.dta", convert.factors=FALSE, convert.underscore=TRUE)

# import simulated data by deciles
decile.data = read.dta("data/simulated_data_deciles.dta", convert.factors=FALSE, convert.underscore=TRUE)

# subset the data by polarization levels into a list
groups <- c(1:8)
datasets<-list()
for(i in 1:8){
  datasets[[i]]<-subset(data, group == groups[i])
}

# subset the data by polarization levels and deciles into a list
pol.cent <- c(1:72)
deciles<-list()
for(i in 1:72){
  deciles[[i]]<-subset(decile.data, group.cent == pol.cent[i])
}

#################################################################################
################################### ATTACKS #####################################
#################################################################################

########## GRAPH WITH RESULTS WITH MEDIAN OUTCOMES -- FIGURE 2 ###############

# fit a gam with negative binomial counts
gam.nb.func <- function(x){
  gam(attack ~ s(seg, k=60), family=negbin(c(1,10)),optimizer="perf",data=x)
}
gams.nb <- lapply(datasets,gam.nb.func)

# take predictions and append them to the dataset
pred.se.func <- function(x){
  predict.gam(x,type="response",se.fit=TRUE)
}
preds.se <- lapply(gams.nb,pred.se.func)

for(i in 1:8){
  datasets[[i]]$preds.nb = preds.se[[i]]$fit
  datasets[[i]]$preds.nb.lo = preds.se[[i]]$fit - 1.96*(preds.se[[i]]$se.fit)
  datasets[[i]]$preds.nb.hi = preds.se[[i]]$fit + 1.96*(preds.se[[i]]$se.fit)
}

# subset the data by polarization levels into a list
sim.preds <- list()
for(i in 1:8){
  sim.preds[[i]]<-subset(sim.preds.data, group == groups[i])
}

# plot the GAM predictions, the data, and the nbreg predictions, and export
png("output/figure_2.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
pols <- c(1.00,0.97,0.93,0.85,0.75,0.55,0.30,0.20)
for(i in 1:8){
  plot(datasets[[i]]$seg,datasets[[i]]$attack,type="p",col="grey",xlab="Segregation",ylab="Attacks",main=paste("Polarization = ",pols[i],""),ylim=c(0,110),xlim=c(0,1))
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb.lo,lty=3)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb.hi,lty=3)
  lines(sim.preds[[i]]$seg,sim.preds[[i]]$m,col="red")
  lines(sim.preds[[i]]$seg,sim.preds[[i]]$lb,lty=3,col="red")
  lines(sim.preds[[i]]$seg,sim.preds[[i]]$ub,lty=3,col="red")
}
dev.off()

########## ANALYSIS BY DECILES -- FIGURE A8 ###############

# fit a gam for each decile
gams.nb.dec <- lapply(deciles,gam.nb.func)

# take predictions for each decile and append them to each dataset
pred.func <- function(x){
  predict.gam(x,type="response")
}

preds.dec <- lapply(gams.nb.dec,pred.func)
for(i in 1:72){
  deciles[[i]]$preds.nb = preds.dec[[i]]
}

# plot by decile for each polarization level
png("output/figure_A8.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
pol.dec <- c(9,18,27,36,45,54,63,72)
for(i in pol.dec){
  plot(deciles[[i]]$seg,deciles[[i]]$preds.nb,type="l",xlab="Segregation",ylab="Attacks",main=paste("Polarization = ",pols[i/9],""),ylim=c(0,110),xlim=c(0,1))
  lines(deciles[[i-1]]$seg,deciles[[i-1]]$preds.nb)
  lines(deciles[[i-2]]$seg,deciles[[i-2]]$preds.nb)
  lines(deciles[[i-3]]$seg,deciles[[i-3]]$preds.nb)
  lines(deciles[[i-4]]$seg,deciles[[i-4]]$preds.nb,lwd=2,col="red")
  lines(deciles[[i-5]]$seg,deciles[[i-5]]$preds.nb)
  lines(deciles[[i-6]]$seg,deciles[[i-6]]$preds.nb)
  lines(deciles[[i-7]]$seg,deciles[[i-7]]$preds.nb)
  lines(deciles[[i-8]]$seg,deciles[[i-8]]$preds.nb)
}
dev.off()

###################################################################################
################################### VICTORIES #####################################
###################################################################################

########## GRAPH WITH RESULTS WITH MEDIAN OUTCOMES -- FIGURE A5 ###############

# fit a gam with negative binomial counts
gam.nb.func <- function(x){
  gam(win ~ s(seg, k=60), family=negbin(c(1,10)),optimizer="perf",data=x)
}
gams.nb <- lapply(datasets,gam.nb.func)

# take predictions and append them to the dataset
preds.se <- lapply(gams.nb,pred.se.func)

for(i in 1:8){
  datasets[[i]]$preds.nb = preds.se[[i]]$fit
  datasets[[i]]$preds.nb.lo = preds.se[[i]]$fit - 1.96*(preds.se[[i]]$se.fit)
  datasets[[i]]$preds.nb.hi = preds.se[[i]]$fit + 1.96*(preds.se[[i]]$se.fit)
}

# plot the predictions and export
png("output/figure_A5.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:8){
  plot(datasets[[i]]$seg,datasets[[i]]$win,type="p",col="grey",xlab="Segregation",ylab="Wins",main=paste("Polarization = ",pols[i],""),ylim=c(0,75),xlim=c(0,1))
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb.lo,lty=3)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.nb.hi,lty=3)
}
dev.off()

########## ANALYSIS BY DECILES -- FIGURE A10 ###############

# fit a gam for each decile
gams.nb.dec <- lapply(deciles,gam.nb.func)

# take predictions for each decile and append them to each dataset
preds.dec <- lapply(gams.nb.dec,pred.func)
for(i in 1:72){
  deciles[[i]]$preds.nb = preds.dec[[i]]
}

# plot by decile for each polarization level
png("output/figure_A10.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in pol.dec){
  plot(deciles[[i]]$seg,deciles[[i]]$preds.nb,type="l",xlab="Segregation",ylab="Wins",main=paste("Polarization = ",pols[i/9],""),ylim=c(0,75),xlim=c(0,1))
  lines(deciles[[i-1]]$seg,deciles[[i-1]]$preds.nb)
  lines(deciles[[i-2]]$seg,deciles[[i-2]]$preds.nb)
  lines(deciles[[i-3]]$seg,deciles[[i-3]]$preds.nb)
  lines(deciles[[i-4]]$seg,deciles[[i-4]]$preds.nb,lwd=2,col="red")
  lines(deciles[[i-5]]$seg,deciles[[i-5]]$preds.nb)
  lines(deciles[[i-6]]$seg,deciles[[i-6]]$preds.nb)
  lines(deciles[[i-7]]$seg,deciles[[i-7]]$preds.nb)
  lines(deciles[[i-8]]$seg,deciles[[i-8]]$preds.nb)
}
dev.off()

######################################################################################
################################### TOTAL EFFORT #####################################
######################################################################################

########## GRAPH WITH RESULTS WITH MEDIAN OUTCOMES -- FIGURE A6 ###############

# fit a gam with the gaussian family
gam.gauss.func <- function(x){
  gam(effort ~ s(seg, k=60), family=gaussian(),optimizer="perf",data=x)
}
gams.gauss <- lapply(datasets,gam.gauss.func)

# take predictions and append them to the dataset
pred.se.func <- function(x){
  predict.gam(x,type="response",se.fit=TRUE)
}
preds.se <- lapply(gams.gauss,pred.se.func)

for(i in 1:8){
  datasets[[i]]$preds.gauss = preds.se[[i]]$fit
  datasets[[i]]$preds.gauss.lo = preds.se[[i]]$fit - 1.96*(preds.se[[i]]$se.fit)
  datasets[[i]]$preds.gauss.hi = preds.se[[i]]$fit + 1.96*(preds.se[[i]]$se.fit)
}

# plot the predictions and export
png("output/figure_A6.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:8){
  plot(datasets[[i]]$seg,datasets[[i]]$effort,type="p",col="grey",xlab="Segregation",ylab="Effort",main=paste("Polarization = ",pols[i],""),ylim=c(0,37),xlim=c(0,1))
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gauss)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gauss.lo,lty=3)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gauss.hi,lty=3)
}
dev.off()

########## ANALYSIS BY DECILES -- FIGURE A9 ###############

# fit a gam for each decile
gams.gauss.dec <- lapply(deciles,gam.gauss.func)

# take predictions for each decile and append them to each dataset
preds.dec <- lapply(gams.gauss.dec,pred.func)
for(i in 1:72){
  deciles[[i]]$preds.gauss = preds.dec[[i]]
}

# plot by decile for each polarization level
png("output/figure_A9.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in pol.dec){
  plot(deciles[[i]]$seg,deciles[[i]]$preds.gauss,type="l",xlab="Segregation",ylab="Effort",main=paste("Polarization = ",pols[i/9],""),ylim=c(0,37),xlim=c(0,1))
  lines(deciles[[i-1]]$seg,deciles[[i-1]]$preds.gauss)
  lines(deciles[[i-2]]$seg,deciles[[i-2]]$preds.gauss)
  lines(deciles[[i-3]]$seg,deciles[[i-3]]$preds.gauss)
  lines(deciles[[i-4]]$seg,deciles[[i-4]]$preds.gauss,lwd=2,col="red")
  lines(deciles[[i-5]]$seg,deciles[[i-5]]$preds.gauss)
  lines(deciles[[i-6]]$seg,deciles[[i-6]]$preds.gauss)
  lines(deciles[[i-7]]$seg,deciles[[i-7]]$preds.gauss)
  lines(deciles[[i-8]]$seg,deciles[[i-8]]$preds.gauss)
}
dev.off()

###########################################################################################
################################### CONFLICT DURATION #####################################
###########################################################################################

########## GRAPH WITH RESULTS WITH MEDIAN OUTCOMES -- FIGURE A7 ###############

# fit a gam with the gamma family
gam.gamma.func <- function(x){
  gam(ticks ~ s(seg, k=60), family=Gamma(),optimizer="perf",data=x)
}
gams.gamma <- lapply(datasets,gam.gamma.func)

# take predictions and append them to the dataset
preds.se <- lapply(gams.gamma,pred.se.func)

for(i in 1:8){
  datasets[[i]]$preds.gamma = preds.se[[i]]$fit
  datasets[[i]]$preds.gamma.lo = preds.se[[i]]$fit - 1.96*(preds.se[[i]]$se.fit)
  datasets[[i]]$preds.gamma.hi = preds.se[[i]]$fit + 1.96*(preds.se[[i]]$se.fit)
}

# plot the predictions and export
png("output/figure_A7.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:8){
  plot(datasets[[i]]$seg,datasets[[i]]$ticks,type="p",col="grey",xlab="Segregation",ylab="Conflict spread",main=paste("Polarization = ",pols[i],""),ylim=c(0,10),xlim=c(0,1))
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gamma)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gamma.lo,lty=3)
  lines(datasets[[i]]$seg,datasets[[i]]$preds.gamma.hi,lty=3)
}
dev.off()

########## ANALYSIS BY DECILES -- FIGURE A11 ###############

# fit a gam for each decile
gams.gamma.dec <- lapply(deciles,gam.gamma.func)

# take predictions for each decile and append them to each dataset
preds.dec <- lapply(gams.gamma.dec,pred.func)
for(i in 1:72){
  deciles[[i]]$preds.gamma = preds.dec[[i]]
}

# plot by decile for each polarization level
png("output/figure_A11.png", width = 950, height = 700)
par(mfrow=c(2,4),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in pol.dec){
  plot(deciles[[i]]$seg,deciles[[i]]$preds.gamma,type="l",xlab="Segregation",ylab="Conflict spread",main=paste("Polarization = ",pols[i/9],""),ylim=c(0,11),xlim=c(0,1))
  lines(deciles[[i-1]]$seg,deciles[[i-1]]$preds.gamma)
  lines(deciles[[i-2]]$seg,deciles[[i-2]]$preds.gamma)
  lines(deciles[[i-3]]$seg,deciles[[i-3]]$preds.gamma)
  lines(deciles[[i-4]]$seg,deciles[[i-4]]$preds.gamma,lwd=2,col="red")
  lines(deciles[[i-5]]$seg,deciles[[i-5]]$preds.gamma)
  lines(deciles[[i-6]]$seg,deciles[[i-6]]$preds.gamma)
  lines(deciles[[i-7]]$seg,deciles[[i-7]]$preds.gamma)
  lines(deciles[[i-8]]$seg,deciles[[i-8]]$preds.gamma)
}
dev.off()

