
# This R script replicates graphs A2-A4 in the online appendix

# load libraries
install.packages("foreign")
library(foreign)

# set the working directory (here, adjust to match the path on your local drive)
setwd("C:/Users/Marko/Dropbox/ABM Dynamics of ethnic war project/data/JCR_seg_pol_replication")

# read in the dataset
data = read.dta("data/simulated_illustration_data.dta", convert.factors=FALSE, convert.underscore=TRUE)

# subset the data by polarization and segregation levels into a list
groups <- c(1:4)
datasets<-list()
for(i in 1:4){
  datasets[[i]]<-subset(data, group == groups[i])
}

# breaks for histogram bars for each variable
cells.attack <- list()
for(i in 1:4){
  cells.attack[[i]] <- c(min(datasets[[i]]$attack):(max(datasets[[i]]$attack + 1)))
}

cells.win <- list()
for(i in 1:4){
  cells.win[[i]] <- c(min(datasets[[i]]$win):(max(datasets[[i]]$win + 1)))
}

cells.effort <- list()
for(i in 1:4){
  cells.effort[[i]] <- c(min(datasets[[i]]$effort):(max(datasets[[i]]$effort + 1)))
}

cells.ticks <- list()
for(i in 1:4){
  cells.ticks[[i]] <- c(min(datasets[[i]]$ticks):(max(datasets[[i]]$ticks + 1)))
}

########## FIGURE A2 -- ATTACKS AND VICTORIES ###############

pols <- c("Polarization = 1, Segregation = 0.95","Polarization = 1, Segregation = 0.07","Polarization = 0.2, Segregation = 0.93","Polarization = 0.2, Segregation = 0.08")
leg.aw.text = c("Attacks", "Wins")
png("output/figure_A2.png", width = 950, height = 700)
par(mfrow=c(2,2),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:2){
  hist(datasets[[i]]$attack,xlab="Count",main=paste(pols[i]),xlim=c(40,120),ylim=c(0,400),breaks=cells.attack[[i]],col="black")
  hist(datasets[[i]]$win,col="grey",border="grey",add=TRUE,breaks=cells.win[[i]])
  legend("top",legend = leg.aw.text,fill=c("black","grey"),border=c("black","grey"))
}
for(i in 3:4){
  hist(datasets[[i]]$attack,xlab="Count",main=paste(pols[i]),xlim=c(0,40),ylim=c(0,1000),breaks=cells.attack[[i]],col="black")
  hist(datasets[[i]]$win,col="grey",border="grey",add=TRUE,breaks=cells.win[[i]])
  legend("top",legend = leg.aw.text,fill=c("black","grey"),border=c("black","grey"))
}
dev.off()

########## FIGURE A3 -- TOTAL EFFORT ###############

png("output/figure_A3.png", width = 950, height = 700)
par(mfrow=c(2,2),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:2){
  hist(datasets[[i]]$effort,xlab="Effort",main=paste(pols[i]),xlim=c(0,40),ylim=c(0,800),breaks=cells.effort[[i]],col="black")
}
for(i in 3:4){
  hist(datasets[[i]]$effort,xlab="Effort",main=paste(pols[i]),xlim=c(0,10),ylim=c(0,1000),breaks=cells.effort[[i]],col="black")
}
dev.off()

########## FIGURE A4 -- CONFLICT DURATION ###############

png("output/figure_A4.png", width = 950, height = 700)
par(mfrow=c(2,2),pty="s",cex.main=1.8,cex.lab=1.8,cex.axis=1.2)
for(i in 1:2){
  hist(datasets[[i]]$ticks,xlab="Number of periods",main=paste(pols[i]),xlim=c(0,25),ylim=c(0,500),breaks=cells.ticks[[i]],col="black")
}
for(i in 3:4){
  hist(datasets[[i]]$ticks,xlab="Number of periods",main=paste(pols[i]),xlim=c(0,10),ylim=c(0,1000),breaks=cells.ticks[[i]],col="black")
}
dev.off()

