The replication archive contains the data and associated do files 
required to replicate the results in the text and the majority of 
the results in the Web Appendix.  

To run the code, extract the archive into a local folder, 
adjust the "cd" line in each do file (current directory) to match the 
pathname of the local folder where datasets have been extracted, and 
then run the do files in their entirety one at a time. 

The data provided are the recoded (and often multiply imputed) versions 
of the original datasets. We will provide the code to transform the original 
data into data used for replication upon request. 

Note, that we cannot provide the original Global Corruption 
Barometer datasets, used to create Table 1 in the Web Appendix, because 
Transparency International requires that the users request them directly 
and sign a user agreement.  We will provide the code to create the results
in Table 1 in the Web Appendix upon request. 

Please send all requests or inquiries about this replication archive to: 

Marko Klasnja
mk3296@nyu.edu
marko.klasnja@gmail.com
